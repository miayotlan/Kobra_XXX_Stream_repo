﻿import xbmcaddon
import xbmcgui
 
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
 
line1 = "ALL KOBRA BUILDS ARE FREE. IF YOU HAVE PURCHASED THIS BUILD, PLEASE ASK FOR A REFUND."
line2 = "SKIN: KOBRA H24 ADULT"
line3 = "BUILD: V 1.0.0"
 
xbmcgui.Dialog().ok(addonname, line1, line2, line3)