################################################################################
#                                                                              #
#                        Copyright (C) 2017 Kobra                              #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
#      Thanks to Surfacingx, ][NT3L][G3NC][, WHUFCLEE, Midraal, OpenELEQ       #
#                                                                              #
################################################################################


import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs
import os, sys
import shutil
import urllib2, urllib
import re
import time

from resources.libs import extract, plugintools, downloader, checkPath


X					= xbmc.executebuiltin
USER_AGENT			= 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'
ADDON_ID 			= 'plugin.program.xxxstream'
ADDON 				= xbmcaddon.Addon(id=ADDON_ID)
ADDONID				='plugin.program.xxxstream'
ADDON_TITLE			="[COLOR darkred][I]KOBRA [/I][/COLOR][COLOR ghostwhite] XXX STREAM WIZARD[/COLOR]"
DIALOG  			= xbmcgui.Dialog()
FANART 				= xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
ICON 				= xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))
ART 				= xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID + '/resources/art/'))
VERSION 			= "0.0.1"
DBPATH 				= xbmc.translatePath('special://database')
TNPATH 				= xbmc.translatePath('special://thumbnails');
BASEURL				= "http://kobracustombuilds.com/adult/build/"
EXCLUDES			= ['']
PATH 				= "Kobra XXX Stream"


#################
### MAIN MENU ###
#################

def INDEX():
    ADD_DIR('[COLOR darkred][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM WIZARD[/COLOR]','noop',0,ART+'kobraxxxwizard.png',FANART,'')
    ADD_DIR('================================================================','noop',0,ART+'',FANART,'')
    ADD_DIR('KOBRA XXX STREAM INSTALL & UPDATES',BASEURL,2,ART+'installandupdates.png',FANART,'')
    ADD_DIR('CONTACT & INFO',BASEURL,8,ART+'contact.png',FANART,'')
    ADD_DIR('MAINTENANCE',BASEURL,3,ART+'maintenance.png',FANART,'')
    ADD_DIR('SETTINGS',BASEURL,10,ART+'settings.png',FANART,'')
    if ADDON.getSetting('devmode') =="true" : ADD_DIR('KOBRA XXX STREAM TEST AREA. PLEASE DO NOT USE',BASEURL+'test.zip',5,ART+'test.png',FANART,'')
    SET_VIEW('list', 'MAIN')


###########################
### BUILD & UPDATE MENU ###
###########################

def BUILD_MENU():
	ADD_DIR('[COLOR darkred][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM INSTALL[/COLOR]','noop',0,ART+'install.png',FANART,'')
	ADD_DIR('================================================================','noop',0,ART+'',FANART,'')
	ADD_DIR('MAUNAL INSTALL KOBRA XXX STREAM (USE TO REPAIR BROKEN BUILD)',BASEURL+'adult.zip',5,ART+'kobraxxxinstall.png',FANART,'')
	ADD_DIR(' ','noop',0,ART+'',FANART,'')
	ADD_DIR('[COLOR darkred][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM UPDATE[/COLOR]','noop',0,ART+'update.png',FANART,'')
	ADD_DIR('================================================================','noop',0,ART+'',FANART,'')
	ADD_DIR('MANUAL INSTALL MINOR UPDATE (ONLY USE IF AUTO UPDATE FAILS)',BASEURL+'adultupdateminor.zip',12,ART+'minorupdate.png',FANART,'')
	ADD_DIR('MANUAL INSTALL MAJOR UPDATE (ONLY USE IF AUTO UPDATE FAILS)',BASEURL+'adultupdatemajor.zip',13,ART+'majorupdate.png',FANART,'')
	SET_VIEW('list', 'MAIN')


########################
### MAINTENANCE EMNU ###
########################

def MAINTENANCE():
	ADD_DIR('[COLOR darkred][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM MAINTENANCE[/COLOR]','noop',0,ART+'maintenance.png',FANART,'')
	ADD_DIR('================================================================','noop',0,ART+'',FANART,'')
	ADD_DIR('DELETE PACKAGES','url',7,ART+'deletepackages.png',FANART,'')
	ADD_DIR('DELETE CACHE','url',4,ART+'deletecache.png',FANART,'')
	ADD_DIR('FRESH START','url',6,ART+'freshstart.png',FANART,'')
	ADD_DIR('FORCE CLOSE','url',14,ART+'forceclose.png',FANART,'')
	SET_VIEW('list', 'MAIN')


########################
### POPUP TEXT BOXES ###
########################

def TEXT_BOXES(heading,announce):
	class TextBox():
		WINDOW=10147
		CONTROL_LABEL=1
		CONTROL_TEXTBOX=5
	def __init__(self,*args,**kwargs):
		X("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
		self.win=xbmcgui.Window(self.WINDOW) # get window
		xbmc.sleep(500) # give window time to initialize
		self.setControls()
	def setControls(self):
		self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
		try: f=open(announce); text=f.read()
		except: text=announce
		self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
		return
	TextBox()

  
###############
### CONTACT ###
###############

def CONTACT_AND_INFO():
    X("RunAddon(plugin.program.kobraXXXStreams.notifications)")


################
### SETTINGS ###
################

def OPEN_SETTINGS():
	ADDON.openSettings()


#################
### CHECK URL ###
#################

def CHECK_URL(url):
	try:
		response = urllib2.urlopen(url)
		code = response.getcode()
		return True
	except urllib2.HTTPError as e:
		return False


#####################
### BUILD INSTALL ###
#####################

def BUILD_WIZARD(name,url,description):
	confirm=xbmcgui.Dialog()
	if confirm.yesno("[COLOR darkred]KOBRA [/COLOR][COLOR ghostwhite]XXX STREAM BUILD INSTALL[/COLOR]","","YOU MUST BE 18 OR OVER TO ACCESS THIS APPLICATION! BEFORE PROCEEDING YOU MUST READ AND AGREE TO THE TERMS BELOW. THE MATERIALS AVAILABLE WITHIN THIS APPLICATION INCLUDE GRAPHIC VISUAL DEPICTIONS AND DESCRIPTIONS OF NUDITY AND SEXUAL ACTIVITY. BY CLICKING I AGREE BELOW, YOU ARE AGREEING TO THE FOLLOWING: 1. YOU ARE AN ADULT, AT LEAST 18 YEARS OF AGE, YOU ARE FAMILIAR WITH AND UNDERSTAND THE STANDARDS AND LAWS OF YOUR LOCAL COMMUNITY REGARDING SEXUALLY-ORIENTED MEDIA. YOU REPRESENT THAT, BASED ON YOUR FAMILIARITY WITH THE STANDARDS AND LAWS OF YOUR LOCAL COMMUNITY, YOU WILL NOT BE VIOLATING ANY APPLICABLE STANDARDS OR LAWS BY REQUESTING, RECEIVING, DOWNLOADING OR POSSESSING ANY OF THE VIDEO, AUDIO, GRAPHICS, IMAGES OR TEXT ADULT MATERIAL AVAILABLE ON THIS APPLICATION. 2. YOU HEREBY ACKNOWLEDGE THAT ANY USE OF THIS APPLICATION IS AT YOUR SOLE RISK. YOU UNDERSTAND THAT BY ACCEPTING THE TERMS OF THIS AGREEMENT, YOU ARE AGREEING TO HOLD THE PUBLISHER OF THIS APPLICATION HARMLESS FROM ANY RESPONSIBILITIES OR LIABILITIES RELATED TO YOUR USE OF THIS APPLICATION AND THE ADULT MATERIAL CONTAINED HEREIN. 3. YOU WILL NOT PERMIT ANY PERSON(S) UNDER 18 YEARS OF AGE TO HAVE ACCESS TO ANY OF THE ADULT MATERIALS CONTAINED IN THIS APPLICATION. 4. YOU ARE VOLUNTARILY CHOOSING TO ACCESS THIS APPLICATION, BECAUSE YOU WANT TO VIEW, READ OR HEAR THE VARIOUS ADULT MATERIALS THAT ARE AVAILABLE. YOU AGREE TO IMMEDIATELY EXIT FROM THIS APPLICATION IF YOU ARE IN ANY WAY OFFENDED BY THE SEXUAL NATURE OF ANY ADULT MATERIAL. 5. IF YOU USE THIS APPLICATION IN VIOLATION OF THESE TERMS, OR USE THIS APPLICATION WHERE SUCH USE IS ILLEGAL, YOU MAY BE IN VIOLATION OF LOCAL AND/OR FEDERAL LAWS. YOU AGREE THAT YOU ARE SOLELY RESPONSIBLE FOR YOUR USE OF THIS APPLICATION AND ANY LINKED THIRD PARTY WEB SITES, AND AGREE TO INDEMNIFY PUBLISHER AGAINST ANY CLAIMS ARISING OUT OF SUCH USE. 6. BY CLICKING I AGREE AT THE BOTTOM OF THIS WINDOW OR BY ENTERING THE APPLICATION, YOU AGREE TO ABIDE BY THE COMPLETE TERMS AND CONDITIONS OF USE OF THIS APPLICATION. IF YOU DO NOT AGREE TO THE COMPLETE TERMS AND CONDITIONS OF USE, CLICK ON THE I DISAGREE BUTTON AND EXIT THE APPLICATION.","","[COLOR orange]I DISAGREE, QUIT[/COLOR]","[COLOR lime]I AGREE, INSTALL[/COLOR]"):
		path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
		dp = xbmcgui.DialogProgress()
		lib=os.path.join(path, name+'.zip')
		dp.create("[COLOR darkred]KOBRA [/COLOR][COLOR ghostwhite]XXX STREAM INSTALL[/COLOR]"," ",'', " ")
		lib=os.path.join(path, name+'.zip')
		try:
			os.remove(lib)
		except:
			pass
		downloader.download(url, lib, dp)
		addonfolder = xbmc.translatePath(os.path.join('special://','home'))
		time.sleep(2)
		dp.update(0,"", "[COLOR ghostwhite]INSTALLING KOBRA XXX STREAM[/COLOR]")
		print '======================================='
		print addonfolder
		print '======================================='
		extract.all(lib,addonfolder,dp)
		dp.close()
		KILL_XBMC()


####################
### MINOR UPDATE ###
####################

def MINOR_UPDATE_WIZARD(name,url,description):
	confirm=xbmcgui.Dialog()
	if confirm.yesno("[COLOR darkred]KOBRA [/COLOR][COLOR ghostwhite]XXX STREAM MINOR UPDATE[/COLOR]","","YOU MUST BE 18 OR OVER TO ACCESS THIS APPLICATION! BEFORE PROCEEDING YOU MUST READ AND AGREE TO THE TERMS BELOW. THE MATERIALS AVAILABLE WITHIN THIS APPLICATION INCLUDE GRAPHIC VISUAL DEPICTIONS AND DESCRIPTIONS OF NUDITY AND SEXUAL ACTIVITY. BY CLICKING I AGREE BELOW, YOU ARE AGREEING TO THE FOLLOWING: 1. YOU ARE AN ADULT, AT LEAST 18 YEARS OF AGE, YOU ARE FAMILIAR WITH AND UNDERSTAND THE STANDARDS AND LAWS OF YOUR LOCAL COMMUNITY REGARDING SEXUALLY-ORIENTED MEDIA. YOU REPRESENT THAT, BASED ON YOUR FAMILIARITY WITH THE STANDARDS AND LAWS OF YOUR LOCAL COMMUNITY, YOU WILL NOT BE VIOLATING ANY APPLICABLE STANDARDS OR LAWS BY REQUESTING, RECEIVING, DOWNLOADING OR POSSESSING ANY OF THE VIDEO, AUDIO, GRAPHICS, IMAGES OR TEXT ADULT MATERIAL AVAILABLE ON THIS APPLICATION. 2. YOU HEREBY ACKNOWLEDGE THAT ANY USE OF THIS APPLICATION IS AT YOUR SOLE RISK. YOU UNDERSTAND THAT BY ACCEPTING THE TERMS OF THIS AGREEMENT, YOU ARE AGREEING TO HOLD THE PUBLISHER OF THIS APPLICATION HARMLESS FROM ANY RESPONSIBILITIES OR LIABILITIES RELATED TO YOUR USE OF THIS APPLICATION AND THE ADULT MATERIAL CONTAINED HEREIN. 3. YOU WILL NOT PERMIT ANY PERSON(S) UNDER 18 YEARS OF AGE TO HAVE ACCESS TO ANY OF THE ADULT MATERIALS CONTAINED IN THIS APPLICATION. 4. YOU ARE VOLUNTARILY CHOOSING TO ACCESS THIS APPLICATION, BECAUSE YOU WANT TO VIEW, READ OR HEAR THE VARIOUS ADULT MATERIALS THAT ARE AVAILABLE. YOU AGREE TO IMMEDIATELY EXIT FROM THIS APPLICATION IF YOU ARE IN ANY WAY OFFENDED BY THE SEXUAL NATURE OF ANY ADULT MATERIAL. 5. IF YOU USE THIS APPLICATION IN VIOLATION OF THESE TERMS, OR USE THIS APPLICATION WHERE SUCH USE IS ILLEGAL, YOU MAY BE IN VIOLATION OF LOCAL AND/OR FEDERAL LAWS. YOU AGREE THAT YOU ARE SOLELY RESPONSIBLE FOR YOUR USE OF THIS APPLICATION AND ANY LINKED THIRD PARTY WEB SITES, AND AGREE TO INDEMNIFY PUBLISHER AGAINST ANY CLAIMS ARISING OUT OF SUCH USE. 6. BY CLICKING I AGREE AT THE BOTTOM OF THIS WINDOW OR BY ENTERING THE APPLICATION, YOU AGREE TO ABIDE BY THE COMPLETE TERMS AND CONDITIONS OF USE OF THIS APPLICATION. IF YOU DO NOT AGREE TO THE COMPLETE TERMS AND CONDITIONS OF USE, CLICK ON THE I DISAGREE BUTTON AND EXIT THE APPLICATION.","","[COLOR orange]I DISAGREE, QUIT[/COLOR]","[COLOR lime]I AGREE, INSTALL[/COLOR]"):
		path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
		dp = xbmcgui.DialogProgress()
		lib=os.path.join(path, name+'.zip')
		dp.create("[COLOR darkred]KOBRA [/COLOR][COLOR ghostwhite]XXX STREAM MINOR UPDATE[/COLOR]"," ",'', " ")
		lib=os.path.join(path, name+'.zip')
		try:
			os.remove(lib)
		except:
			pass
		downloader.download(url, lib, dp)
		addonfolder = xbmc.translatePath(os.path.join('special://','home'))
		time.sleep(2)
		dp.update(0,"", "[COLOR ghostwhite]INSTALLING MINOR UPDATE[/COLOR]")
		print '======================================='
		print addonfolder
		print '======================================='
		extract.all(lib,addonfolder,dp)
		dp.close()
		DIALOG.ok("[COLOR darkred]KOBRA [/COLOR][COLOR ghostwhite]XXX STREAM MINOR UPDATE[/COLOR]", "[COLOR ghostwhite][CR]WE NOW NEED TO RELOAD THE SKIN TO APPLY THE CHANGES. PRESS OK TO CONTINUE[/COLOR]")
		X('ReloadSkin()')


####################
### MINOR UPDATE ###
####################

def MAJOR_UPDATE_WIZARD(name,url,description):
	confirm=xbmcgui.Dialog()
	if confirm.yesno("[COLOR darkred]KOBRA [/COLOR][COLOR ghostwhite]XXX STREAM MAJOR UPDATE[/COLOR]","","YOU MUST BE 18 OR OVER TO ACCESS THIS APPLICATION! BEFORE PROCEEDING YOU MUST READ AND AGREE TO THE TERMS BELOW. THE MATERIALS AVAILABLE WITHIN THIS APPLICATION INCLUDE GRAPHIC VISUAL DEPICTIONS AND DESCRIPTIONS OF NUDITY AND SEXUAL ACTIVITY. BY CLICKING I AGREE BELOW, YOU ARE AGREEING TO THE FOLLOWING: 1. YOU ARE AN ADULT, AT LEAST 18 YEARS OF AGE, YOU ARE FAMILIAR WITH AND UNDERSTAND THE STANDARDS AND LAWS OF YOUR LOCAL COMMUNITY REGARDING SEXUALLY-ORIENTED MEDIA. YOU REPRESENT THAT, BASED ON YOUR FAMILIARITY WITH THE STANDARDS AND LAWS OF YOUR LOCAL COMMUNITY, YOU WILL NOT BE VIOLATING ANY APPLICABLE STANDARDS OR LAWS BY REQUESTING, RECEIVING, DOWNLOADING OR POSSESSING ANY OF THE VIDEO, AUDIO, GRAPHICS, IMAGES OR TEXT ADULT MATERIAL AVAILABLE ON THIS APPLICATION. 2. YOU HEREBY ACKNOWLEDGE THAT ANY USE OF THIS APPLICATION IS AT YOUR SOLE RISK. YOU UNDERSTAND THAT BY ACCEPTING THE TERMS OF THIS AGREEMENT, YOU ARE AGREEING TO HOLD THE PUBLISHER OF THIS APPLICATION HARMLESS FROM ANY RESPONSIBILITIES OR LIABILITIES RELATED TO YOUR USE OF THIS APPLICATION AND THE ADULT MATERIAL CONTAINED HEREIN. 3. YOU WILL NOT PERMIT ANY PERSON(S) UNDER 18 YEARS OF AGE TO HAVE ACCESS TO ANY OF THE ADULT MATERIALS CONTAINED IN THIS APPLICATION. 4. YOU ARE VOLUNTARILY CHOOSING TO ACCESS THIS APPLICATION, BECAUSE YOU WANT TO VIEW, READ OR HEAR THE VARIOUS ADULT MATERIALS THAT ARE AVAILABLE. YOU AGREE TO IMMEDIATELY EXIT FROM THIS APPLICATION IF YOU ARE IN ANY WAY OFFENDED BY THE SEXUAL NATURE OF ANY ADULT MATERIAL. 5. IF YOU USE THIS APPLICATION IN VIOLATION OF THESE TERMS, OR USE THIS APPLICATION WHERE SUCH USE IS ILLEGAL, YOU MAY BE IN VIOLATION OF LOCAL AND/OR FEDERAL LAWS. YOU AGREE THAT YOU ARE SOLELY RESPONSIBLE FOR YOUR USE OF THIS APPLICATION AND ANY LINKED THIRD PARTY WEB SITES, AND AGREE TO INDEMNIFY PUBLISHER AGAINST ANY CLAIMS ARISING OUT OF SUCH USE. 6. BY CLICKING I AGREE AT THE BOTTOM OF THIS WINDOW OR BY ENTERING THE APPLICATION, YOU AGREE TO ABIDE BY THE COMPLETE TERMS AND CONDITIONS OF USE OF THIS APPLICATION. IF YOU DO NOT AGREE TO THE COMPLETE TERMS AND CONDITIONS OF USE, CLICK ON THE I DISAGREE BUTTON AND EXIT THE APPLICATION.","","[COLOR orange]I DISAGREE, QUIT[/COLOR]","[COLOR lime]I AGREE, INSTALL[/COLOR]"):
		path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
		dp = xbmcgui.DialogProgress()
		lib=os.path.join(path, name+'.zip')
		dp.create("[COLOR darkred]KOBRA [/COLOR][COLOR ghostwhite]XXX STREAM MAJOR UPDATE[/COLOR]"," ",'', " ")
		lib=os.path.join(path, name+'.zip')
		try:
			os.remove(lib)
		except:
			pass
		downloader.download(url, lib, dp)
		addonfolder = xbmc.translatePath(os.path.join('special://','home'))
		time.sleep(2)
		dp.update(0,"", "[COLOR ghostwhite]INSTALLING MAJOR UPDATE[/COLOR]")
		print '======================================='
		print addonfolder
		print '======================================='
		extract.all(lib,addonfolder,dp)
		dp.close()
		KILL_XBMC()


############################
### DELETE PACKAGES ########
### THANKS GUYS @ XUNITY ###
############################

def DELETE_PACKAGES():
    xbmc.log('####        KOBRA MAINTENANCE: DELETING PACKAGE FILES        ####')
    PACKAGES = xbmc.translatePath('special://home/addons/packages')
    if os.path.exists(PACKAGES):
        try:
            for root, dirs, files in os.walk(PACKAGES):
                file_count = 0
                file_count += len(files)
                # Count files and give option to delete
                if file_count > 0:
                    if DIALOG.yesno("[COLOR darkred][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM MAINTENANCE[/COLOR]","[CR]Clear packages", str(file_count) + " File(S) found", "Would you like to remove?", nolabel='[COLOR orange]NO, CANCEL[/COLOR]',yeslabel='[COLOR lime]YES, REMOVE[/COLOR]'):
                        for f in files: os.unlink(os.path.join(root, f))
                        for d in dirs: shutil.rmtree(os.path.join(root, d))
                        DIALOG.ok('[COLOR darkred][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM MAINTENANCE[/COLOR]','[CR][CR]Clear packages: [COLOR lime] Success[/COLOR]')
                else: DIALOG.ok('[COLOR darkred][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM MAINTENANCE[/COLOR]','[CR][CR]Clear packages: None Found')
        except: DIALOG.ok('[COLOR darkred][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM MAINTENANCE[/COLOR]','[CR][CR]Clear packages: Error')
    else: DIALOG.ok('[COLOR darkred][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM MAINTENANCE[/COLOR]','[CR][CR]Clear packages: None found')


############################
### DELETE CACHE ###########
### THANKS GUYS @ XUNITY ###
############################

def DELETE_CACHE_FILES():
	xbmc.log('####        KOBRA MAINTENANCE: DELETING CACHE FILES        ####')
	xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
	if os.path.exists(xbmc_cache_path)==True:
		for root, dirs, files in os.walk(xbmc_cache_path):
			file_count = 0
			file_count += len(files)
		# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete Cache Files", str(file_count) + " [CR]Files found", "Do you want to delete them?"):
					for f in files:
						try:
							os.unlink(os.path.join(root, f))
						except:
							pass
					for d in dirs:
						try:
							shutil.rmtree(os.path.join(root, d))
						except:
							pass
			else:
				pass
	if xbmc.getCondVisibility('system.platform.ATV2'):
		atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
		for root, dirs, files in os.walk(atv2_cache_a):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				if DIALOG.yesno("Delete ATV2 Cache Files", str(file_count) + " [CR]Files found in 'Other'", "Do you want to delete them?"):
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
			else:
				pass
		atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
		for root, dirs, files in os.walk(atv2_cache_b):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				if DIALOG.yesno("Delete ATV2 Cache Files", str(file_count) + " [CR]Files found in 'LocalAndRental'", "Do you want to delete them?"):
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
			else:
				pass
			  # Set path to Cydia Archives cache files
	# Set path to What th Furk cache files
	wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
	if os.path.exists(wtf_cache_path)==True:
		for root, dirs, files in os.walk(wtf_cache_path):
			file_count = 0
			file_count += len(files)
		# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete WTF Cache Files", str(file_count) + " [CR]Files found", "Do you want to delete them?"):
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
			else:
				pass
				# Set path to 4oD cache files
	channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
	if os.path.exists(channel4_cache_path)==True:
		for root, dirs, files in os.walk(channel4_cache_path):
			file_count = 0
			file_count += len(files)
		# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete 4oD Cache Files", str(file_count) + " [CR]Files found", "Do you want to delete them?"):
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
			else:
				pass
				# Set path to BBC iPlayer cache files
	iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
	if os.path.exists(iplayer_cache_path)==True:
		for root, dirs, files in os.walk(iplayer_cache_path):
			file_count = 0
			file_count += len(files)
		# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " [CR]Files found", "Do you want to delete them?"):
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
			else:
				pass
				# Set path to Simple Downloader cache files
	downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
	if os.path.exists(downloader_cache_path)==True:
		for root, dirs, files in os.walk(downloader_cache_path):
			file_count = 0
			file_count += len(files)
		# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete Simple Downloader Cache Files", str(file_count) + " [CR]Files found", "Do you want to delete them?"):
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
			else:
				pass
				# Set path to ITV cache files
	itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
	if os.path.exists(itv_cache_path)==True:
		for root, dirs, files in os.walk(itv_cache_path):
			file_count = 0
			file_count += len(files)
		# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete ITV Cache Files", str(file_count) + " [CR]Files found", "Do you want to delete them?"):
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
			else:
				pass
				# Set path to temp cache files
	temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
	if os.path.exists(temp_cache_path)==True:
		for root, dirs, files in os.walk(temp_cache_path):
			file_count = 0
			file_count += len(files)
		# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete TEMP dir Cache Files", str(file_count) + " [CR]Files found", "Do you want to delete them?"):
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
			else:
				pass
	DIALOG.ok("[COLOR darkred][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM MAINTENANCE[/COLOR]", "[CR]All Cache Files Removed", "Brought To You By Kobra XXX Stream")


################
### OPEN URL ###
################

def OPEN_URL(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', USER_AGENT)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


########################
### FORCE CLOSE KODI ###
########################

def KILL_XBMC():
	DIALOG.ok("[COLOR darkred]KOBRA [/COLOR][COLOR ghostwhite]XXX STREAM FORCE CLOSE[/COLOR]", "[COLOR ghostwhite][CR]WE NOW NEED TO FORCE CLOSE KOBRA XXX STREAM FOR THE CHANGES TO BE APPLIED. PLEASE RESTART THE APPLICATION.  PRESS OK TO CONTINUE[/COLOR]")
	xbmc.log("Force Closing Kodi")
	os._exit(1)

def FORCE_CLOSE():
	confirm=xbmcgui.Dialog()
	if confirm.yesno("[COLOR darkred]KOBRA [/COLOR][COLOR ghostwhite]XXX STREAM FORCE CLOSE[/COLOR]","","[COLOR ghostwhite][CR]YOU ARE ABOUT TO FORCE CLOSE KOBRA XXX STREAM[/COLOR]","[COLOR ghostwhite]WOULD YOU LIKE TO CONTINUE?[/COLOR]","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, FORCE CLOSE[/COLOR]"):
		xbmc.log("Force Closing Kodi")
		os._exit(1)
	else:
		pass


##########################
### DETERMINE PLATFORM ###
##########################

def PLATFORM():
	if xbmc.getCondVisibility('system.platform.android'):
		return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):
		return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):
		return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):
		return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):
		return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):
		return 'ios'


##########################
### FRESH START ##########
### THANKS TO TVADDONS ###
##########################

def FRESHSTART(params):
	plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(ADDON_TITLE,"[CR]Do you wish to restore your","configuration to default settings?")
	if yes_pressed:
		addonPath=xbmcaddon.Addon(id=ADDONID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath);
		xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
		try:
			for root, dirs, files in os.walk(xbmcPath,topdown=True):
				dirs[:] = [d for d in dirs if d not in EXCLUDES]
				for name in files:
					try: os.remove(os.path.join(root,name))
					except:
						if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
						plugintools.log("Error removing "+root+" "+name)
				for name in dirs:
					try: os.rmdir(os.path.join(root,name))
					except:
						if name not in ["Database","userdata"]: failed=True
						plugintools.log("Error removing "+root+" "+name)
			if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(ADDON_TITLE,"The process is complete, you're now back to a fresh Kobra XXX Stream configuration with Kobra XXX!","Please reboot your system or restart Kobra XXX Stream in order for the changes to be applied.")
			else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(ADDON_TITLE,"The process is complete, you're now back to a fresh Kobra XXX Stream configuration with Kobra XXX Stream","Please reboot your system or restart Kobra XXX in order for the changes to be applied.")
		except: plugintools.message(ADDON_TITLE,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
		plugintools.add_item(action="",title="Now Exit The Media Center",folder=False)
	else: plugintools.message(ADDON_TITLE,"[CR]Your settings","has not been changed")
	FORCE_CLOSE()


###########################
### BLACK MAGIC: VOODOO ###
###########################

def GET_PARAMS():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]

		return param


#####################
### ADD DIRECTORY ###
#####################

def ADD_DIR(name,url,mode,iconimage,fanart,description):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
		liz.setProperty( "Fanart_Image", fanart )
		if mode==4 or mode==5 or mode ==6 or mode==7 or mode==8 or mode==10 or mode==12 or mode==13 or mode==14 or  url=='noop':
			ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		else:
			ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok


#################
### SET VIEWS ###
#################

def SET_VIEW(content, viewType):
	# set content type so library shows more views and info
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if ADDON.getSetting('auto-view')=='true':
		X("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )


###################
### MORE VOODOO ###
###################

params=GET_PARAMS()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		iconimage=urllib.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass
try:
		fanart=urllib.unquote_plus(params["fanart"])
except:
		pass
try:
		description=urllib.unquote_plus(params["description"])
except:
		pass


print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


if mode==None or url==None or len(url)<1:	INDEX()

elif mode==2:	BUILD_MENU()

elif mode==3:	MAINTENANCE()

elif mode==4:	DELETE_CACHE_FILES()

elif mode==5:	BUILD_WIZARD(name,url,description)

elif mode==6:	FRESHSTART(params)

elif mode==7:	DELETE_PACKAGES()

elif mode==8:	CONTACT_AND_INFO()

elif mode==10:	OPEN_SETTINGS()

elif mode==11:	DELETEIVUEDB()

elif mode==12:	MINOR_UPDATE_WIZARD(name,url,description)

elif mode==13:	MAJOR_UPDATE_WIZARD(name,url,description)

elif mode==14:	FORCE_CLOSE()


xbmcplugin.endOfDirectory(int(sys.argv[1]))