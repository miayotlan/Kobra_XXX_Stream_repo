import xbmc,string,logging,array
import common as Common

import xbmcaddon
import xbmc
import time


time.sleep(10)
TypeOfMessage="t"; (NewImage,NewMessage)=Common.FetchNews(); 
Common.CheckNews(TypeOfMessage,NewImage,NewMessage,True); 